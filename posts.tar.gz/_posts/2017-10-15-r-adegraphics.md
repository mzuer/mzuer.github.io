---
layout: post
title: "<em>adegraphics</em>: improved plotting functions for multivariate analyses"
date: 2017-10-15
category: R
tags: [R, package]
---

Improved functionalities of the <em>ade4</em> package implemented in the <em>adegraphics</em> package.


https://cran.r-project.org/web/packages/adegraphics/vignettes/adegraphics.html



