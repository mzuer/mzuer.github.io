---
layout: post
title: "Bash - number of columns in file (<em>awk</em>)"
date: 2017-08-26
category: bash
tags: [bash, awk]
---

```
awk '{print NF; exit}' filename.txt
```
