---
layout: post
title: "Create interactive svg tables"
date: 2017-10-15
category: R
tags: [R, plot]
---


https://www.r-bloggers.com/creating-interactive-svg-tables-in-r/
