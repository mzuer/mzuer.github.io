---
layout: post
title: "Bash - post to git (<em>git</em>)"
date: 2017-08-26
category: bash
tags: [bash, git]
---

```
git add *.R
git commit -a -m "message"
git push
```
