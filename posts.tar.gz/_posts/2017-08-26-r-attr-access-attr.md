---
layout: post
title: "<em>attr</em>: access object attributes"
date: 2017-08-26
category: R
tags: [R, function, object]
---

```
attr(x, "names")

attr(x, "dim")
```

