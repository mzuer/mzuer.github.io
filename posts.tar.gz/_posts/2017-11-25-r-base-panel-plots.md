---
layout: post
title: "R - multiple panels with R base plots"
date: 2017-11-25
category: R
tags: [R, plots]
---

http://seananderson.ca/courses/11-multipanel/multipanel.pdf
