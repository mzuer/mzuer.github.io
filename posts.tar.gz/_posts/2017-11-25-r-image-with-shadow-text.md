---
layout: post
title: "R - add shadow text on plot"
date: 2017-11-25
category: R
tags: [R, plots]
---


https://cran.r-project.org/web/packages/shadowtext/vignettes/shadowtext.html
