---
layout: post
title: "R - trellis (lattice plots)"
date: 2017-11-25
category: R
tags: [R, plots]
---

http://ml.stat.purdue.edu/stat695t/writings/Trellis.User.pdf

http://ml.stat.purdue.edu/stat695t/writings/

