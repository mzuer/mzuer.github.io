---
layout: post
title: "bash - install python module in specific folder"
date: 2017-11-25
category: bash
tags: [bash, python, module]
---

Install python module in a specific folder

```
pip install --target=d:\somewhere\other\than\the\default package_name
```
