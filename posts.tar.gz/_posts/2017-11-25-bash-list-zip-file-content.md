---
layout: post
title: "bash - list the content of an archive file"
date: 2017-11-25
category: bash
tags: [bash, archive]
---


https://www.cyberciti.biz/faq/list-the-contents-of-a-tar-or-targz-file/

