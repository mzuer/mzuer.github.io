---
layout: post
title: "R - drawing flowcharts in R and <em>Gmisc</em> package"
date: 2018-06-03
category: R
tags: R flowchart plot package
---

Examples for drawing flowcharts in R:

https://www.r-bloggers.com/flow-charts-in-r/

https://cran.r-project.org/web/packages/Gmisc/vignettes/Grid-based_flowcharts.html

https://cran.r-project.org/web/packages/Gmisc/


