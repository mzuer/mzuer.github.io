---
layout: post
title: "R - Descriptive mAchine Learning EXplanations: <em>DALEX</em> package"
date: 2018-04-01
category: R
tags: R package
---

https://pbiecek.github.io/DALEX/
