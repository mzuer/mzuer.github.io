---
layout: post
title: "R - review of various <em>geoms</em> and <em>aes</em> from <em>ggplot2</em>"
date: 2018-04-01
category: R
tags: R plot
---


https://www.r-bloggers.com/ggplot2-how-geoms-aesthetics-%e2%89%88-whipped-cream/
