---
layout: post
title: "<em>plot(..., bty="l")</em>: no box but lines"
date: 2017-08-26
category: R
tags: [R, function, plot]
---

parameter to draw simple x and y lines instead of box around the plot

```
plot(..., bty='l')
```


<small> viewed on http://www.rfunction.com </small>
