---
layout: post
title: "R - <em>ggrough</em> package: convert ggplots in sketchy plots"
date: 2018-08-13
category: R
tags: R package ggplot2 plot
---

<em>ggrough</em>: convert ggplots in sketchy plots

https://xvrdm.github.io/ggrough/
