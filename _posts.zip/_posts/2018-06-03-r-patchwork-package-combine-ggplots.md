---
layout: post
title: "R - <em>patchwork</em> package to combine <em>ggplots</em>"
date: 2018-06-03
category: R
tags: R package plot ggplot2
---

*<em>patchwork</em> package: 

https://github.com/thomasp85/patchwork
