---
layout: post
title: "R - <em>chromoMap</em>: R package for chromosome visualization"
date: 2018-08-13
category: R
tags: R package visualization plot
---


<em>chromoMap</em>: package for interactive visualization and mapping of human chromosomes

https://cran.r-project.org/web/packages/chromoMap/vignettes/chromoMap.html


