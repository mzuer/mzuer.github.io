---
layout: post
title: "R - <em>ggforce</em>: package, create plots that are zoom of ggplot"
date: 2018-08-13
category: R
tags: R package plot ggplot2
---

https://github.com/thomasp85/ggforce


https://cran.r-project.org/web/packages/ggforce/index.html
