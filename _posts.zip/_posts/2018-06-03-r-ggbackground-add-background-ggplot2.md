---
layout: post
title: "R - <em>ggbackground</em>: set background to ggplots"
date: 2018-06-03
category: R
tags: R plot ggplot2 function
---

<em>ggbackground</em> to set ggplot2 background:

https://www.r-bloggers.com/setting-ggplot2-background-with-ggbackground/



