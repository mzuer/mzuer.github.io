---
layout: post
title: "R - add curve on base plot"
date: 2017-11-25
category: R
tags: [R, plots]
---

Add a curve on existing plot:

```
curve(x^2, from=1, to=50, , xlab="x", ylab="y")
```
