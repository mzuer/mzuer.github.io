---
layout: post
title: "Bash - <em>du</em> (disk usage) in most human readable format"
date: 2018-01-21
category: bash
tags: [bash]
---

```
du -sh
```
