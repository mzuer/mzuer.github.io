---
layout: post
title: "R - different ways to pass a formula to <em>lm()</em>"
date: 2018-10-03
category: R
tags: R function
---


Examples of different ways to pass a formula to <em>lm()</em>

<a href="https://www.r-bloggers.com/r-tip-how-to-pass-a-formula-to-lm">https://www.r-bloggers.com/r-tip-how-to-pass-a-formula-to-lm</a>
