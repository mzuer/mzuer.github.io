---
layout: post
title: "R - <em>ggplotify</em> or <em>base2grob</em> to convert base plots to <em>ggplot</em> and <em>grob</em> objects"
date: 2018-06-03
category: R
tags: R package plot function ggplot2
---

*<em>ggplotify</em> package: 

https://cran.r-project.org/web/packages/ggplotify/vignettes/ggplotify.html



*<em>base2grob</em> package:

https://cran.r-project.org/web/packages/base2grob/vignettes/base2grob.html


