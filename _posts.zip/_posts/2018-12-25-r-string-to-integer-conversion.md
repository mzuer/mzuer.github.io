---
layout: post
title: "R - string to integer conversion with <em>strtoi</em>"
date: 2018-12-25
category: R
tags: R function string
---

Convert strings to integers of a given base with <em>strtoi</em>


```
strtoi(c("101010", "11111000101"), base =  2L)
# [1]   42 1989
```

