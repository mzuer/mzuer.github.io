---
layout: post
title: "R - Rcpp code accessible from foreach loop using package"
date: 2018-01-21
category: R
tags: [R, Rcpp, parallelization, loop]
---

Make Rccp code accessible with <em>foreach</em> loop using R package:

https://www.r-bloggers.com/divide-and-parallelize-large-data-problems-with-rcpp


