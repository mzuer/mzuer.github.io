---
layout: post
title: "R - math symbols in plots with <em>plotmath</em>"
date: 2018-06-03
category: R
tags: R function plot
---

math symbols in R base plots with <em>plotmath</em>


```
demo(plotmath)
```
