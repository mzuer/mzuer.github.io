---
layout: post
title: "R - create heatmap with barplot"
date: 2018-08-13
category: R
tags: R barplot heatmap plot
---

Different ways for creating heatmap with barplot:

1) ComplexHeatmap
https://bioconductor.org/packages/devel/bioc/vignettes/ComplexHeatmap/inst/doc/s4.heatmap_annotation.html


2) vcfR
heatmap.bp


3) superheat (ggplot2)
https://rlbarter.github.io/superheat/


4) custom heatmap.bp_mz

