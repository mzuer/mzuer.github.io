---
layout: post
title: "R - <em>sweep</em> function"
date: 2017-11-25
category: R
tags: [R, function]
---

https://bioinfomagician.wordpress.com/2014/08/12/my-favorite-commands-part3-sweep-function-in-r/

