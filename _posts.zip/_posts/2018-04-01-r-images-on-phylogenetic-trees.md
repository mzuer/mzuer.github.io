---
layout: post
title: "R - annotate phylogenetic trees (<em>ggtree</em> and <em>ggimage</em>)"
date: 2018-04-01
category: R
tags: R plot package
---

Pyhlogenetic tree with images using <em>ggtree</em> and <em>ggimage</em>

https://www.r-bloggers.com/annotating-phylogenetic-tree-with-images-using-ggtree-and-ggimage/
