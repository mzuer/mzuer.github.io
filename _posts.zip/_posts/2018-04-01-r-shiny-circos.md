---
layout: post
title: "R - Shiny application for <em>Circos</em>"
date: 2018-04-01
category: R
tags: R plot
---

Shiny application developed for circos


https://github.com/venyao/shinyCircos
