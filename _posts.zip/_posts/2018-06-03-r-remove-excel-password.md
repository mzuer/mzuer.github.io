---
layout: post
title: "R - remove Excel sheet passwords with R"
date: 2018-06-03
category: R
tags: R function hack
---


https://www.r-bloggers.com/remove-password-protection-from-excel-sheets-using-r/
