---
layout: post
title: "<em>officer</em> package: create office documents with R"
date: 2017-10-15
category: R
tags: [R, package]
---

https://cran.r-project.org/web/packages/officer/vignettes/word.html

https://cran.r-project.org/web/packages/officer/vignettes/powerpoint.html
