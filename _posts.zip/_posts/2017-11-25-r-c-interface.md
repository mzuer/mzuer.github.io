---
layout: post
title: "R - C interface (.C and .Call)"
date: 2017-11-25
category: R
tags: [R, C]
---

http://www.biostat.jhsph.edu/~rpeng/docs/interface.pdf

