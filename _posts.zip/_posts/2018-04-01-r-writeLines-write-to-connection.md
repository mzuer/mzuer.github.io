---
layout: post
title: "R - <em>writeLines</em> to write to a connection"
date: 2018-06-03
category: R
tags: R function output
---

<em>writeLines</em> can be used to write to a connection 


```
writeLines(text, con = stdout(), sep = "\n", useBytes = FALSE)
```
