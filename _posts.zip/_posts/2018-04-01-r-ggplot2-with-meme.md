---
layout: post
title: "R - <em>ggplot2</em> plots with meme images"
date: 2018-04-01
category: R
tags: R plot
---

https://www.r-bloggers.com/mix-ggplot2-graphs-with-your-favorite-memes-memery-0-4-2-released/
