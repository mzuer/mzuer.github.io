---
layout: post
title: "R - <em>bquote</em> and <em>expression</em> for math notations in plot title"
date: 2018-04-01
category: R
tags: R plot
---

https://www.r-bloggers.com/math-notation-for-r-plot-titles-expression-and-bquote/
