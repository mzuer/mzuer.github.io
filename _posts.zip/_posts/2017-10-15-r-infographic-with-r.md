---
layout: post
title: "infographic with R"
date: 2017-10-15
category: R
tags: [R, plot]
---

https://www.r-bloggers.com/r-how-to-layout-and-design-an-infographic/
