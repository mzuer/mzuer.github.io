---
layout: post
title: "Bash - <em>ls</em> in most human readable format"
date: 2018-01-21
category: bash
tags: [bash]
---


```
ls -ahnt
```
