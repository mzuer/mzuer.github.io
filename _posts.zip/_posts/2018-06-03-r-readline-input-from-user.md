---
layout: post
title: "R - get input form user using <em>readline</em> function"
date: 2018-06-03
category: R
tags: R function
---

Retrieve input from user using <em>readline</em> function


```
my_num <- as.integer(readline(prompt="Enter a number: "))

```
