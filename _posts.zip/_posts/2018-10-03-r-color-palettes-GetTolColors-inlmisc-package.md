---
layout: post
title: "R - color palettes with <em>GetTolColors()</em> from <em>inlmisc</em> package"
date: 2018-10-03
category: R
tags: R colors palettes package function
---


https://www.r-bloggers.com/tol-color-schemes/



