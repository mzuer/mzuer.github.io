---
layout: post
title: "R - key points book <em>Rstudio for statistical computing</em>"
date: 2018-10-03
category: R
tags: R book Rstudio
---

Keypoints from interesting chapters from the book "Rstudio for statistical computing":

- chapter3 
Using pairs.panel() to look at (visualize) correlations between variable

- chapter3
Showing communities in a network with the linkcomm package	

- chapter4
Producing a Sankey diagram with the networkD3 package	

- chapter4
Creating a dynamic force network with the visNetwork package	

- chapter4
Using the DiagrammeR package to produce a process flow diagram

- chapter6
Performing time series decomposition using the stl() function	

- chapter6
Exploring time series forecasting with forecast()	

- chapter6
Tracking stock movements using the quantmod package	

