---
layout: post
title: "R - zoning methods: <em>geozoning</em> package"
date: 2018-04-01
category: R
tags: R package
---

<em>geozoning</em>: package for zoning methods for spatial data (with functions for zoning quality assessment)

https://cran.r-project.org/web/packages/geozoning/index.html
