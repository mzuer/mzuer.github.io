---
layout: post
title: "R - create custom <em>ggplot2</em> themes"
date: 2018-10-03
category: R
tags: R plot ggplot2
---


<a href="https://www.r-bloggers.com/custom-themes-in-ggplot2"> https://www.r-bloggers.com/custom-themes-in-ggplot2 </a>
