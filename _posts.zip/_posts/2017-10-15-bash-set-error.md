---
layout: post
title: "Bash - exit if error (<em>set -e</em>)"
date: 2017-10-15
category: bash
tags: [bash]
---

Add <em>set -e</em> at the beginning of the script to exit the script if an error occurs.
