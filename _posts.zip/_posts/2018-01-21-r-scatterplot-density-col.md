---
layout: post
title: "R - scatter plot with density colors"
date: 2018-01-21
category: R
tags: R plot
---


For R base plots:

https://stackoverflow.com/questions/17093935/r-scatter-plot-symbol-color-represents-number-of-overlapping-points



Using ggplot2:

http://wresch.github.io/2012/11/06/ggplot2-smoothscatter.html
