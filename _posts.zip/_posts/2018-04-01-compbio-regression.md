---
layout: post
title: "compbio - types of regression [link]"
date: 2018-04-01
category: compbio
tags: compbio statistics
---


https://www.r-bloggers.com/15-types-of-regression-you-should-know/


