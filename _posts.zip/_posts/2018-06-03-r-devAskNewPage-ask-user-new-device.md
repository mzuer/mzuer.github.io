---
layout: post
title: "R - ask user if prompted for new device with <em>devAskNewPage</em>"
date: 2018-06-03
category: R
tags: R plot function
---



<em>devAskNewPage</em> can be used to control (for the current device) whether the user is prompted before starting a new page of output

```
devAskNewPage(ask = NULL)
```


