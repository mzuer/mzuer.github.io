---
layout: post
title: "bash - skip <em>n</em> first lines with <em>tail</em>"
date: 2018-04-01
category: bash
tags: bash
---

For example, to skip the first two lines of a file:

```
tail -q -n+2 myfile.txt
```


