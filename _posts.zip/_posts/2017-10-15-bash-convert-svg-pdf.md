---
layout: post
title: "Bash- convert svg to pdf (<em>inkscape</em>)"
date: 2017-10-15
category: bash
tags: [bash, picture]
---

```
inkscape -f  infile.svg -A outfile.pdf
```
