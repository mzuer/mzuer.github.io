---
layout: post
title: "R - R and docker"
date: 2018-04-01
category: R
tags: R
---

https://www.r-bloggers.com/r-and-docker-2/
