---
layout: post
title: "R - <em>ggtern</em> package: ternary diagrams"
date: 2018-08-13
category: R
tags: R package ggplot2 plot
---

<em>ggtern</em>: extension of ggplot2 for creating ternary diagrams in R

http://www.ggtern.com
