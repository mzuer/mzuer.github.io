---
layout: post
title: "R - tips for statistics, <em>Hmisc</em> and other packages"
date: 2018-10-03
category: R
tags: R statistics package
---

Vanderbilt Biostatistics Wiki: <em>Hmisc</em> and other R tips around statistics

<a href="http://biostat.mc.vanderbilt.edu/wiki/Main/RS">http://biostat.mc.vanderbilt.edu/wiki/Main/RS</a>
