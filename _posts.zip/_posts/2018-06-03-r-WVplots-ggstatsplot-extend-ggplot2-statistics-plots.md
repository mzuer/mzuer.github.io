---
layout: post
title: "R - <em>WVPlots</em> and <em>ggstatsplot</em> powerful packages extend <em>ggplot2</em> for statistics plots"
date: 2018-06-03
category: R
tags: R package plot ggplot2
---


Powerful packages built on ggplot2 for statistics plot:

* <em>WVPlots</em> package

https://cran.r-project.org/web/packages/WVPlots/index.html
https://github.com/WinVector/WVPlots


* <em>ggstatsplot</em> package

https://cran.r-project.org/web/packages/ggstatsplot/index.html
https://github.com/IndrajeetPatil/ggstatsplot

