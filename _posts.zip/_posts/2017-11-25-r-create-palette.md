---
layout: post
title: "R - create palette"
date: 2017-11-25
category: R
tags: [R, colors]
---

colorRampPalette(c('red','white','blue'))(12))

