---
layout: post
title: "R - add marginal plots in the margin of a plot"
date: 2018-08-13
category: R
tags: R plot function package
---

Add marginal plots on ggpubr plots:

Perfect Scatter Plots with Correlation and Marginal Histograms 
http://www.sthda.com/english/articles/24-ggpubr-publication-ready-plots/78-perfect-scatter-plots-with-correlation-and-marginal-histograms/

see also <em>ggMarginal</em> from </em> ggExtra package

https://github.com/daattali/ggExtra

