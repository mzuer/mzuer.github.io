---
layout: post
title: "R - create code snippets for Rstudio"
date: 2018-12-25
category: R
tags: R Rstudio
---

Code snippets are text macros that are used for quickly inserting common snippets of code. 

(used for auto-completion)

<a href=https://www.r-bloggers.com/4-ways-to-be-more-efficient-using-rstudios-code-snippets-with-11-ready-to-use-examples>https://www.r-bloggers.com/4-ways-to-be-more-efficient-using-rstudios-code-snippets-with-11-ready-to-use-examples</a>

<a href=https://support.rstudio.com/hc/en-us/articles/204463668-Code-Snippets?version=1.0.143&mode=desktop>https://support.rstudio.com/hc/en-us/articles/204463668-Code-Snippets?version=1.0.143&mode=desktop</a>
