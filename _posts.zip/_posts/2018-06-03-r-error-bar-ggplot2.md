---
layout: post
title: "R - error bar in ggplot2 with <em>geom_errorbar</em>"
date: 2018-06-03
category: R
tags: R function plot ggplot2
---

To add error bars in ggplot2, use: <em>geom_errorbar</em> 


