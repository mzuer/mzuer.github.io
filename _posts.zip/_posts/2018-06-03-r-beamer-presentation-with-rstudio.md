---
layout: post
title: "R - beamer presentation with Rstudio"
date: 2018-06-03
category: R
tags: R Rstudio presentation
---


https://rmarkdown.rstudio.com/beamer_presentation_format.html
