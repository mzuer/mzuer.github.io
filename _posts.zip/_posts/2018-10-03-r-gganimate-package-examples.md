---
layout: post
title: "R - animated ggplots with <em>gganimate</em> package"
date: 2018-10-03
category: R
tags: R plot package
---


Examples to create animated ggplot2 plots with <em>gganimate</em> package:

<a href="https://www.r-bloggers.com/animating-the-premier-league-using-gganimate">https://www.r-bloggers.com/animating-the-premier-league-using-gganimate</a>
