---
layout: post
title: "Blog data analysis (link)"
date: 2018-08-13
category: R
tags: R visualization statistics
---

Nice blog for data analysis stuff:

http://www.rebeccabarter.com
