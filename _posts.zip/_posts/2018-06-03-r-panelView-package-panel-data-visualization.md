---
layout: post
title: "R - <em>panelView</em> package for panel data visualization"
date: 2018-06-03
category: R
tags: R package plot statistics
---


</em>panelView</em> package: Visualizing Panel Data with Dichotomous Treatments

http://yiqingxu.org/software/panelView/panelView.html


