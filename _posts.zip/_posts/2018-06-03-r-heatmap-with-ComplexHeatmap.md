---
layout: post
title: "R - heatmap with <em>ComplexHeatmap</em> package"
date: 2018-06-03
category: R
tags: R package plot ggplot2 heatmap bioconductor
---

R bioconductor package <em>ComplexHeatmap</em> for complex heatmap plotting:


http://bioconductor.org/packages/release/bioc/html/ComplexHeatmap.html
