---
layout: post
title: "R - customized ggplot2 boxplots"
date: 2018-01-02
category: R
tags: [R, plots, ggplot2]
---

Change ggplot2 boxplot layout, funny fonts, etc.:

http://t-redactyl.io/blog/2016/04/creating-plots-in-r-using-ggplot2-part-10-boxplots.html
