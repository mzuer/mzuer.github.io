---
layout: post
title: "R - mastering software development"
date: 2018-01-02
category: R
tags: [R, ressource]
---

https://bookdown.org/rdpeng/RProgDA/
