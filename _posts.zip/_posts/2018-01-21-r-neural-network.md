---
layout: post
title: "R - neural network from scratch"
date: 2018-01-21
category: R
tags: [R, Rcpp, machine_learning]
---

http://selbydavid.com/2018/01/09/neural-network/
