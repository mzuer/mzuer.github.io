---
layout: post
title: "R - draw sequence logo with <em>seqLogo</em> package"
date: 2018-06-03
category: R
tags: R bioinformatics plot bioconductor package
---

Plot sequence motifs/logos with <em>seqLogo</em> package (bioconductor) 


https://bioconductor.org/packages/release/bioc/vignettes/seqLogo/inst/doc/seqLogo.pdf
