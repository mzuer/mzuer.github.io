---
layout: post
title: "R - links to functions and packages to draw heatmaps"
date: 2018-06-03
category: R
tags: R package plot function heatmap
---

*<em>heatmap.2</em> function: 

https://davetang.org/muse/2010/12/06/making-a-heatmap-with-r/


*<em>ComplexHeatmap</em> package:

http://bioconductor.org/packages/release/bioc/html/ComplexHeatmap.html



*<em>pheatmap</em> package: 

https://davetang.org/muse/2018/05/15/making-a-heatmap-in-r-with-the-pheatmap-package/



*<em>superheat</em> package: 

https://davetang.org/muse/2017/02/06/making-heatmap-r-superheat-package/ (can add side plots)



*<em>heatmap3</em> package: 

https://cran.r-project.org/web/packages/heatmap3/vignettes/vignette.pdf



* other information:
http://compbio.ucsd.edu/making-heat-maps-r/



