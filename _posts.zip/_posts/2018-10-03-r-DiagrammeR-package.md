---
layout: post
title: "R - create diagramms with the <em>DiagrammeR</em> package"
date: 2018-10-03
category: R
tags: R plot package
---

<em>DiagrammeR</em> package to create diagrams in R

<a href="http://rich-iannone.github.io/DiagrammeR/graph_creation.html">http://rich-iannone.github.io/DiagrammeR/graph_creation.html</a>
